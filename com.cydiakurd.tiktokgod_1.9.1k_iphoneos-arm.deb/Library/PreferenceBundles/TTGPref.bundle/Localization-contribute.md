I'm working on localization, if you like my tweak and want to help, you can help me translate to your language.

(Finished languages are in the same directory of this file)

After you finished translation, Please save and name it with your language code (if you don't know, just write down your country name)

E.g: English -> en, Japanese -> ja, Vietnamese -> vi...

And your nick name, I will add to Contributors part.

Finally, send me the result to my email "hao.ict56@gmail.com" or open issue or pull request on Github.
